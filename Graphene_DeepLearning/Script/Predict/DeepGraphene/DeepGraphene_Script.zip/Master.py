# -*- coding: utf-8 -*-
"""
Created on Tue Feb 20 22:05:17 2018

@author: Herman Wu
"""

import os
 
import numpy as np
import Data_processing
import Network_standard
import Concat_Net
import Residual_Net
import Inception_Net
import Freeze_Result

import time 
from keras.models import load_model

#if __name__==' __main__':
Local_dir = os.path.dirname(__file__)
Base_dir=(Local_dir.split('Script'))[0]
sph=Base_dir+'/dataset'
Freeze_Result.main()
###########################################################################################################
Epc=250
#Type='ResNet'
#Type='ConcatNet'
Type='CNN'
#Type='Inception'
TransferLearning=False
###########################################################################################################
Input_X=[]  
Input_Y=[]
Test_X=[]
Test_Y=[]
Input_X,Input_Y=Data_processing.Data_process(sph,Four_num=14870,Five_num=47695,Six_num=6382)
Test_X,Test_Y=Data_processing.Test_Data_process(sph,1000)
#new_X=Data_processing.new_Data_process(Base_dir,1000)
print('/*******************************************************/')
print(' \n           Finished Loading the Data!!  \n ')
print('  Choosing '+Type+ ' type of Network to train the dataset \n')
print('/*******************************************************/')
time.sleep(2)
###########################################################################################################
if Type=='CNN':
    Model=Network_standard.main(Base_dir,Input_X,Input_Y,epoch=Epc,batch_size=512,TF=TransferLearning)
elif Type=='ConcatNet':
    Model=Concat_Net.main(Base_dir,Input_X,Input_Y,epoch=Epc,batch_size=128,TF=TransferLearning)
elif Type=='Inception':
    Model=Inception_Net.main(Base_dir,Input_X,Input_Y,epoch=Epc,batch_size=256,TF=TransferLearning)
elif Type=='ResNet':
    Model=Residual_Net.main(Base_dir,Input_X,Input_Y,epoch=Epc,batch_size=512,TF=TransferLearning)      
print('            Finished Training the Network!!  \n ')
print('/*******************************************************/')
###########################################################################################################
#Test_X,Test_Y=Data_processing.Test_Data_process(Base_dir,266)
Test_4by4=Test_X['4by4_data']
Test_5by5=Test_X['5by5_data']
Test_6by6=Test_X['6by6_data']
temp1=(Model.predict(Test_4by4))*4.6    
temp2=(Model.predict(Test_5by5))*4.6
#temp_2=(Model.predict(Test_6by6))*4.6
temp3=Test_Y['4by4_data']*4.6
temp4=Test_Y['5by5_data']*4.6
#temp_4=Test_Y['6by6_data']*4.6
Prediction=np.concatenate((temp1,temp2),axis=0)
#Prediction=temp1
#Prediction=temp2
#Prediction=temp_2
#Real=temp3
#Real=temp4
#Real=temp_4
Real=np.concatenate((temp3,temp4),axis=0)
###########################################################################################################
rela_error=0
abs_error=0
per_error=0
temp_ava=len(Real)
for index,i in enumerate(Real):
    if Prediction[index]==0:
        temp_ava+=-1
    else:
        temp=abs(Prediction[index]-i)/Prediction[index]
        rela_error+=temp
rela_error=rela_error/temp_ava

for index,i in enumerate(Real):
    if i!=0:
        temp=abs(Prediction[index]-i)
        abs_error+=temp
    
abs_error=abs_error/2000
per_error=rela_error*100
print('/*******************************************************/')
print(' \n     The  relative error is:'+str(rela_error)+'   \n')
print(' \n     The  Absolute error is:'+str(abs_error)+'   \n')
print(' \n     The  Percent error is : '+str(per_error)+' %   \n')
print('/*******************************************************/')
###########################################################################################################
#new_4by4=new_X['4by4_data']
#new_5by5=new_X['5by5_data']
#new_5by5_result=(Model.predict(new_5by5))*4.6
#new_4by4_result=(Model.predict(new_4by4))*4.6
